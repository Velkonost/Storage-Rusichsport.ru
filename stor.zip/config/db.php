<?php

return [
    'class' => 'yii\db\Connection',
     'dsn' => 'mysql:host=localhost;dbname=rusich',
     'username' => 'sport_form',
     'password' => '!RsLkI0PBf4a0!',
     'charset' => 'utf8',
];