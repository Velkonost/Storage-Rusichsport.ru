<?php
		namespace app\models;
		use yii\db\ActiveRecord;
		use yii\web\IdentityInterface;
		use yii\base\NotSupportedException;
		use Yii;
		
		class Tasks extends ActiveRecord
		{
		}
?>